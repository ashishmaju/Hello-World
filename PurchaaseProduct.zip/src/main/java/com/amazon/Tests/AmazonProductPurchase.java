package com.amazon.Tests;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.support.PageFactory;
import org.testng.annotations.Test;

import com.amazon.Pages.HomePage;
import com.amazon.Pages.ProductPage;
import com.amazon.Pages.SignInPage;

public class AmazonProductPurchase extends TestBase
{

	@Test
	public void init() throws InterruptedException
	{
		
		HomePage home=PageFactory.initElements(driver, HomePage.class);
		
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		
		home.setTextToSerchBox("Raincoat men");
		
		home.clickOnSearch();
		
		Thread.sleep(5000);
		
		ProductPage product=PageFactory.initElements(driver,ProductPage.class);
		
		product.ClickOnProduct();
		
		product.selectBySize(4);
		
		Thread.sleep(6000);
		
		product.ClickonBuyNow();
		
		SignInPage signin=PageFactory.initElements(driver, SignInPage.class);
		
		signin.SetUserName("ashishmaju@gmail.com");
		
		signin.SetUserPassword("Amazon@12345");
		
		signin.ClickonSignIn();
		
		
	}
	
	
	
	
}
