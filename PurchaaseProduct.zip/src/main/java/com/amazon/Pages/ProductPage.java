package com.amazon.Pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.Test;

public class ProductPage 
{
	WebDriver driver=null;
	
	public ProductPage(WebDriver driver)
	{
		this.driver=driver;
	}
	
	
	
@FindBy (how=How.XPATH, using="//img[@title=\"Mountain Warehouse Brisk Extreme Mens Waterproof Rain Jacket - Warm\"]/..") WebElement raincoat;

@FindBy (how=How.XPATH, using="//span[@class=\"a-dropdown-prompt\"][contains(text(),\"Select\")]") WebElement selectDropDown;

@FindBy (how=How.ID,using="native_dropdown_selected_size_name") WebElement selectSize;

@FindBy (how=How.ID, using="buy-now-button") WebElement BuyNow;


public void ClickOnProduct()
{
	
	raincoat.click();
}


public void selectDropDown()
{

	selectDropDown.click();
}



public void selectBySize(int size)
{

	Select select=new Select(selectSize);
	
	select.selectByIndex(size);
	
}


public void ClickonBuyNow()
{

	BuyNow.click();
}

}
