package com.amazon.Pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.testng.annotations.Test;

public class SignInPage 
{
	WebDriver driver=null;
	
	
	public SignInPage(WebDriver driver) {
	
		this.driver=driver;
	}
	
	
	@FindBy (how=How.NAME, using="email") WebElement Email;
	@FindBy (how=How.NAME, using="password") WebElement password;
	@FindBy (how=How.ID, using= "signInSubmit") WebElement SignInButton;
	
	
	
	public void SetUserName(String userEmail)
	{
		Email.sendKeys(userEmail);
		
	}

	
	public void SetUserPassword(String UserPassword)
	{
		password.sendKeys(UserPassword);
	}
	

	public void ClickonSignIn()
	
	{
		SignInButton.click();
		
		
	}
}
