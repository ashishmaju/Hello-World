package com.amazon.Pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.testng.annotations.Test;

public class HomePage
{
	WebDriver driver=null;
	
	public HomePage(WebDriver driver)
	{
		this.driver=driver;
		PageFactory.initElements(driver, this);
	}
	
	
	
	@FindBy(how=How.ID, using="twotabsearchtextbox") WebElement searchbox;
	@FindBy(how=How.XPATH, using="(//div[@class='nav-right'])[2]") WebElement searchbutton;
	

	
	public void setTextToSerchBox(String str)
	{
		
		searchbox.sendKeys(str);
		
	}
	
	

	public void clickOnSearch()
	{
		searchbutton.click();
		
	}
	
}
